jQuery(document).ready(function ($) {
    function initLightboxEvents() {
        // Variables globales pour suivre l'image actuelle et la liste des images
        var images = [];
        var currentIndex = -1;

        // Sélectionne les éléments de la lightbox et des boutons de fermeture
        var btnFermetureLightbox = $('.lightClose');

        // Lorsqu'on clique sur un bouton avec la classe '.fullscreen-icon'
        $(document).on('click', '.fullscreen-icon', function() {
            var image = $(this);
            var urlImage = image.data('full');
            var categoryImage = image.data('category');
            var referenceImage = image.data('reference');

            // Débogage : Vérifiez les valeurs récupérées
            console.log("Données de l'image:", {
                url: urlImage,
                category: categoryImage,
                reference: referenceImage
            });

            if (!urlImage) {
                console.error('L\'URL de l\'image est vide.');
                return;
            }

            // Mettre à jour la lightbox avec l'image sélectionnée et ses informations
            $('.lightImage').attr('src', urlImage);
            $('.lightCategorie').text(categoryImage);
            $('.lightReference').text(referenceImage);
            transitionPopup($('.lightbox'), 1); // Affiche la lightbox avec effet de transition

            // Met à jour les images et l'index actuel
            images = $('.fullscreen-icon').map(function() {
                return {
                    url: $(this).data('full'),
                    category: $(this).data('category'),
                    reference: $(this).data('reference')
                };
            }).get();
            currentIndex = $('.fullscreen-icon').index(image);
        });

        // Lorsqu'on clique sur le bouton de fermeture de la lightbox
        btnFermetureLightbox.click(function() {
            transitionPopup($('.lightbox'), 0); // Ferme la lightbox avec effet de transition
        });

        // Fonction pour effectuer une transition d'affichage avec une opacité donnée
        function transitionPopup(element, opacity) {
            $(element).css('display', opacity === 1 ? 'flex' : 'none');
            $(element).animate({ opacity: opacity }, 500); // Utilisation de la variable dureeTransitionPopup
        }

        // Gérer la navigation entre les images dans la lightbox
        $('.lightPrevious, .lightNext').click(function() {
            if ($(this).hasClass('lightPrevious')) {
                currentIndex = (currentIndex - 1 + images.length) % images.length;
            } else {
                currentIndex = (currentIndex + 1) % images.length;
            }
            var image = images[currentIndex];
            $('.lightImage').attr('src', image.url);
            $('.lightCategorie').text(image.category);
            $('.lightReference').text(image.reference);
        });
    }

    // Initialiser les événements de la lightbox lors du chargement initial de la page
    initLightboxEvents();

    // Réattacher les événements après un chargement AJAX
    $(document).ajaxComplete(function() {
        initLightboxEvents();
    });
});
