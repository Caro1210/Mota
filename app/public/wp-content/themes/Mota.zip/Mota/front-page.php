<?php 

get_header();

get_template_part("templates_parts/hero");
get_template_part("templates_parts/filtres");
get_template_part("templates_parts/catalogue");

get_footer(); 


