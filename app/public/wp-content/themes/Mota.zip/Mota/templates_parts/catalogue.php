<?php
function afficherImages($query, $reset_postdata = true) {
    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            
            // Récupérer l'URL de la photo depuis le champ ACF
            $photoUrl = get_field('photo');

            // Récupérer les autres informations nécessaires
            $photo_titre = get_the_title();
            $post_url = get_permalink();
            $reference = get_field('reference');
            $categorie = get_the_terms(get_the_ID(), 'categorie');
            $categorie_name = '';

            if ($categorie && !is_wp_error($categorie) && !empty($categorie)) {
                $categorie_name = $categorie[0]->name;
            }
            ?>

            <div class="blockPhotoRelative">
                <!-- Afficher l'image avec son URL et un texte alternatif -->
                <?php if ($photoUrl) : ?>
                    <img src="<?php echo esc_url($photoUrl); ?>" alt="<?php the_title_attribute(); ?>">
                <?php else : ?>
                    <p>Image non disponible</p>
                    <img src="<?php echo esc_url(get_the_post_thumbnail_url()); ?>" alt="<?php the_title_attribute(); ?>">
                <?php endif; ?>

                <div class="overlay">
                    <!-- Afficher le titre de la photo -->
                    <h2><?php echo esc_html($photo_titre); ?></h2>

                    <!-- Afficher le nom de la catégorie s'il est disponible -->
                    <?php if ($categorie_name) : ?>
                        <h3><?php echo esc_html($categorie_name); ?></h3>
                    <?php endif; ?>

                    <!-- Icône pour voir la photo en détail -->
                    <div class="eye-icon">
                        <a href="<?php echo esc_url($post_url); ?>">
                            <img src="<?php echo get_template_directory_uri() . '/images/eye.png'; ?>" alt="voir la photo">
                        </a>
                    </div>

                    <!-- Vérifier si la référence est définie avant d'afficher l'icône fullscreen -->
                    <?php if ($reference) : ?>
                        <div class="fullscreen-icon" data-full="<?php echo esc_attr($photoUrl); ?>" data-category="<?php echo esc_attr($categorie_name); ?>" data-reference="<?php echo esc_attr($reference); ?>">
                            <img src="<?php echo get_template_directory_uri() . '/images/icon_fullscreen.png'; ?>" alt="Plein écran">
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <?php
        }

        if ($reset_postdata) {
            wp_reset_postdata();
        }
    } else {
        echo 'Aucune photo trouvée.';
    }
}

$args = array(
    'post_type'      => 'photo', 
    'posts_per_page' => 8,
    'order'          => 'ASC',
);
$photo_block = new WP_Query($args);
?>

<div class="galerie__photos colonnes">
    <?php afficherImages($photo_block); ?>
</div>

<!-- Bloc pour le chargement de plus de photos -->
<div id="load-moreContainer">
    <button id="btnLoad-more" data-page="1" data-url="<?php echo admin_url('admin-ajax.php'); ?>">Charger plus</button>
</div>
